//Array contains elements of same datatype 

#include <stdio.h>
#include <stdlib.h>
#include <bits/stdc++.h>

using namespace std;
int arr[6]; //global declaration   //max size[10^7]

int main (){

    //declaring an array (local declaration)
    int array[6];      //max size[10^6]
    
    cout << sizeof(array) << endl;
    for (int i = 0; i < sizeof(array); i++)
    {
        cout << array[i] << endl;
    }
    
    return 0;
}
